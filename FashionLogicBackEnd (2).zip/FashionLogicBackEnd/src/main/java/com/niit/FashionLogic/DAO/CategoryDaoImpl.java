package com.niit.FashionLogic.DAO;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.FashionLogic.Model.Category;
@Transactional
@Repository("categoryDao")
public class CategoryDaoImpl implements CategoryDao {
	@Autowired
	private SessionFactory sessionFactory;
	
	public boolean addCategory(Category category1) {
		try {
			System.out.println("we are in add method of daoimpl");
			System.out.println(category1.getCategoryId());
			sessionFactory.getCurrentSession().persist(category1);
			System.out.println(sessionFactory);
			System.out.println("we are after saving product");
			return true;}catch(Exception e) {
				System.out.println("Exception handled");
				System.out.println(e);	
				return false;
		}	
	}
	public boolean updateCategory(Category category) {
		System.out.println("we are in update method of daoimpl");
		sessionFactory.getCurrentSession().update(category);
		return true;
	}
	public boolean deleteCategory(int categoryId) {
		sessionFactory.getCurrentSession().delete(findByCategoryId(categoryId));	
		return true;

		
	}
	public Category findByCategoryId(int categoryId) {
		return (Category) sessionFactory.getCurrentSession().
				createQuery("from Category where categoryId="+categoryId).
				uniqueResult();
}
	@SuppressWarnings("unchecked")
	public List<Category> findAllCategory() {
		
		return sessionFactory.getCurrentSession()
				.createQuery("from Category")
				.list();
	}		
}
