package com.niit.FashionLogic.DAO;

import java.util.List;

import org.springframework.stereotype.Component;

import com.niit.FashionLogic.Model.Product;
@Component("productDao")
public interface ProductDao {
	
	public boolean addProduct(Product product);
	public boolean updateProduct(Product product);
	public boolean deleteProduct(int prodId);
	public Product findByProductId(int prodId);
	public List<Product> findAll();
}
