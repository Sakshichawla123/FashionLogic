package com.niit.FashionLogic.DAO;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.FashionLogic.Model.Product;
@Transactional
@Repository("productDao")

public class ProductDaoImpl implements ProductDao {
		@Autowired
		private SessionFactory sessionFactory;
		public boolean addProduct(Product product1) {
			try {
			System.out.println("we are in add method of daoimpl");
			System.out.println(product1.getProdId());
			sessionFactory.getCurrentSession().persist(product1);
			System.out.println(sessionFactory);
			System.out.println("we are after saving product");
			return true;}catch(Exception e) {
				System.out.println("Exception handled");
				System.out.println(e);	
				return false;
			}	
		}
		public boolean updateProduct(Product product2) {
			System.out.println("we are in update method of daoimpl");
			sessionFactory.getCurrentSession().update(product2);
			return true;
		}
		public boolean deleteProduct(int prodId) {
			sessionFactory.getCurrentSession().delete(findByProductId(prodId));	
			return true;

			
		}
		public Product findByProductId(int prodId) {
			return (Product) sessionFactory.getCurrentSession().
					createQuery("from Product where prodId="+prodId).
					uniqueResult();
}
		@SuppressWarnings("unchecked")
		public List<Product> findAll() {
			
			return sessionFactory.getCurrentSession()
					.createQuery("from Product")
					.list();
		}		
}