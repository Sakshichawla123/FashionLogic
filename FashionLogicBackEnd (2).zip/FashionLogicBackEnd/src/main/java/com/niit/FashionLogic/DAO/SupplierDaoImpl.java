package com.niit.FashionLogic.DAO;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.FashionLogic.Model.Supplier;

@Transactional
@Repository("supplierDao")
public class SupplierDaoImpl implements SupplierDao {
	@Autowired
	private SessionFactory sessionFactory;
	
	public boolean addSupplier(Supplier supplier1) {
		try {
		System.out.println("we are in add method of daoimpl");
		System.out.println(supplier1.getSupplierId());
		sessionFactory.getCurrentSession().persist(supplier1);
		System.out.println(sessionFactory);
		System.out.println("we are after saving product");
		return true;}catch(Exception e) {
			System.out.println("Exception handled");
			System.out.println(e);	
			return false;
		}	
	}
	public boolean updateSupplier(Supplier supplier2) {
		System.out.println("we are in update method of daoimpl");
		sessionFactory.getCurrentSession().update(supplier2);
		return true;
	}
	public boolean deleteSupplier(int supplierId) {
		sessionFactory.getCurrentSession().delete(findBySupplierId(supplierId));	
		return true;

		
	}
	public Supplier findBySupplierId(int supplierId) {
		return (Supplier) sessionFactory.getCurrentSession().
				createQuery("from Supplier where supplierId="+supplierId).
				uniqueResult();
}
	@SuppressWarnings("unchecked")
	public List<Supplier> findAllSupplier() {
		
		return sessionFactory.getCurrentSession()
				.createQuery("from Supplier")
				.list();
	}
		
}
