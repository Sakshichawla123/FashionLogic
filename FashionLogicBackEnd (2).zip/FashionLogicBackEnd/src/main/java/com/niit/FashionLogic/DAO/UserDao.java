package com.niit.FashionLogic.DAO;

import java.util.List;

import com.niit.FashionLogic.Model.Supplier;
import com.niit.FashionLogic.Model.User;

public interface UserDao {
	public boolean addUser(User user);
	public boolean updateUser(User user);
	public boolean deleteUser(String email);
	public Supplier findByUserId(String email);
	public List<User> findAllUser();
	public boolean loginUser(String email, String password);
}
