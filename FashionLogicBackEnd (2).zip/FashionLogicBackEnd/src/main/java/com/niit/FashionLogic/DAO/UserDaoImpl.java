package com.niit.FashionLogic.DAO;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.FashionLogic.Model.Supplier;
import com.niit.FashionLogic.Model.User;
@Transactional
@Repository("userDao")
public class UserDaoImpl implements UserDao{
	@Autowired
	private SessionFactory sessionFactory;
	public boolean addUser(User user1) {
		try {
			System.out.println("we are in add method of daoimpl");
			
			sessionFactory.getCurrentSession().save(user1);
			System.out.println(sessionFactory);
			System.out.println(user1);
			System.out.println("we are after saving user");
			return true;}catch(Exception e) {
				System.out.println("Exception handled");
				System.out.println(e);	
				return false;
			}	
	}

	public boolean updateUser(User user) {
		
		return false;
	}

	public boolean deleteUser(String email) {
		
		return false;
	}

	public Supplier findByUserId(String email) {
		
		return null;
	}

	public List<User> findAllUser() {
		
		return null;
	}

	public boolean loginUser(String email, String password) {
		try {
			Query que=sessionFactory.getCurrentSession().createQuery("from User where email=:email and password=:password");
			que.setParameter("email", email);
			que.setParameter("password", password);
		
			if(que==null)
				return false;
			else
			return true;
		}
		catch(Exception exception)
			{
		exception.printStackTrace();

		return false;
	}

}}