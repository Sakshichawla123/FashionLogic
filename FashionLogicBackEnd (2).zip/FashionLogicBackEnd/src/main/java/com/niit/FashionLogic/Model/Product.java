package com.niit.FashionLogic.Model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="product")

public class Product implements Serializable{	
		private static final long serialVersionUID = 1L;
		@Id
		@NonNull
		private int prodId;
		public String getProdBrand() {
			return prodBrand;
		}
		public void setProdBrand(String prodBrand) {
			this.prodBrand = prodBrand;
		}
		public String getCategoryName() {
			return categoryName;
		}
		public void setCategoryName(String categoryName) {
			this.categoryName = categoryName;
		}
		public String getSupplierName() {
			return supplierName;
		}
		public void setSupplierName(String supplierName) {
			this.supplierName = supplierName;
		}
		@NonNull
		private String prodName;
		@NonNull
		private String prodBrand;
		@NonNull
		private int prodPrice;
		@NonNull
		private int prodqty;
		@NonNull
		private String prodDescription;
		@NonNull
		private String categoryName;
		@NonNull
		private String supplierName;
		public int getProdqty() {
			return prodqty;
		}
		public void setProdqty(int prodqty) {
			this.prodqty = prodqty;
		}
		public String getProdDescription() {
			return prodDescription;
		}
		public void setProdDescription(String prodDescription) {
			this.prodDescription = prodDescription;
		}
		public int getProdId() {
			return prodId;
		}
		public void setProdId(int prodId) {
			this.prodId = prodId;
		}
		public String getProdName() {
			return prodName;
		}
		public void setProdName(String prodName) {
			this.prodName = prodName;
		}
		public int getProdPrice() {
			return prodPrice;
		}
		public void setProdPrice(int prodPrice) {
			this.prodPrice = prodPrice;
		}
		
		
}
