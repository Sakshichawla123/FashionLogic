package com.niit.FashionLogic.Model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
@Component
@Entity
@Table(name="supplier")
public class Supplier implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@NonNull
	private int supplierId;
	@NonNull
	private String supplierName;
	@NonNull
	private String supplierDesc;
	public int getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getSupplierDesc() {
		return supplierDesc;
	}
	public void setSupplierDesc(String supplierDesc) {
		this.supplierDesc = supplierDesc;
	}
	
	
}
