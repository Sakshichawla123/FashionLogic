package com.niit.FashionLogic.FashionLogicBackEnd;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.FashionLogic.DAO.CategoryDao;
import com.niit.FashionLogic.Model.Category;

public class CategoryTest {
	@Autowired
	private static CategoryDao categoryDao;
	private static Category category;
	private static AnnotationConfigApplicationContext context;
	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.*");
		context.refresh();
		categoryDao = (CategoryDao) context.getBean("categoryDao");
	}
	
	@Test
	public void testAddCategory() {
category=new Category();
category.setCategoryId(4);
category.setCategoryName("Traditional Wear");
category.setCategoryDesc("Traditional wear");
		assertEquals("Successfully added the categories",true, categoryDao.addCategory(category));

	}
	/*
	@Test
	public void testUpdateProduct() {
		category=new Category();
		category.setCategoryId(3);
		category.setCategoryName("Traditional Wear");
		category.setCategoryDesc("Traditional wear !! All Brands");
				assertEquals("Successfully updated the categories",true, categoryDao.updateCategory(category));

}
	@Test
	public void testDeleteCategory() {
		Category c=new Category();
		c.setCategoryId(2);
		assertEquals("Successfully deleted the category",true, categoryDao.deleteCategory(c.getCategoryId()));
	}
	
	@Test
	public void testCategoryById() {
		Category c1=new Category();
		assertEquals(1, categoryDao.findByCategoryId(1).getCategoryId());
	}
	@Test
	public void testFindAllCategory() {
		
		assertEquals(1,categoryDao.findAllCategory().size());
	}

*/
}
