package com.niit.FashionLogic.FashionLogicBackEnd;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.FashionLogic.DAO.ProductDao;
import com.niit.FashionLogic.Model.Product;

public class ProductTest {
	@Autowired
	private static ProductDao productDao;
	private static Product product;
	private static AnnotationConfigApplicationContext context;
	
	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.*");
		context.refresh();
		productDao = (ProductDao) context.getBean("productDao");
		//product =  (Product) context.getBean("product");
	}
	@Test
	@Ignore
	public void setup() {
		product.setProdId(1001);
		product.setProdName("Jeans");
		product.setProdPrice(3102);
		product.setProdqty(3);
		product.setProdDescription("Slim Fit Dennim Jean");
		productDao.addProduct(product);
	}
	
	@Test
	public void testAddProduct() {
product=new Product();
		product.setProdId(1001);
		product.setProdName("1 to 3 years kids wear");
		product.setProdBrand("Reebok");
		product.setProdPrice(1500);
		product.setProdqty(20);
		product.setProdDescription("Kids wear");
		product.setCategoryName("Kids Wear");
		product.setSupplierName("reebok");
		assertEquals("Successfully added the products",true, productDao.addProduct(product));

	}
	/*
	@Test
	public void testUpdateProduct() {
		Product product1=new Product();
		product1.setProdId(1001);
		product1.setProdName("pants");
		product1.setProdPrice(1020);
		product1.setProdqty(5);
		product1.setProdDescription("Denim Pants");
		assertEquals("Successfully updated the products",true, productDao.updateProduct(product1));
}
	@Test
	public void testDeleteProduct() {
		Product p=new Product();
		p.setProdId(1003);
		assertEquals("Successfully deleted the products",true, productDao.deleteProduct(p.getProdId()));
	}
	@Test
	public void testProductById() {
		Product p1=new Product();
		assertEquals(1001, productDao.findByProductId(1001).getProdId());
	}
	@Test
	public void testFindAllProducts() {
		
		assertEquals(3,productDao.findAll().size());
	}*/
}
