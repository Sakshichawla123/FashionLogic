package com.niit.FashionLogic.FashionLogicBackEnd;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.FashionLogic.DAO.SupplierDao;
import com.niit.FashionLogic.Model.Supplier;

public class SupplierTest {
	@Autowired
	private static SupplierDao supplierDao;
	private static Supplier supplier;
	private static AnnotationConfigApplicationContext context;
	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.*");
		context.refresh();
		supplierDao = (SupplierDao) context.getBean("supplierDao");
		//product =  (Product) context.getBean("product");
	}
	/*
	@Test
	public void testAddSupplier() {
supplier=new Supplier();
supplier.setSupplierId(1);
supplier.setSupplierName("abc");
supplier.setSupplierDesc("Deals in all brands");
		assertEquals("Successfully added the supplier list",true, supplierDao.addSupplier(supplier));

	}*/
	
	@Test
	public void testUpdateSupplier() {
		supplier=new Supplier();
supplier.setSupplierId(1);
supplier.setSupplierName("xyz");
supplier.setSupplierDesc("Deals in all brands");
		assertEquals("Successfully updated the supplier list",true, supplierDao.updateSupplier(supplier));

}
	@Test
	public void testDeleteSupplier() {
		Supplier s=new Supplier();
		s.setSupplierId(1);
		assertEquals("Successfully deleted the Supplier",true, supplierDao.deleteSupplier(s.getSupplierId()));
	}
	
	@Test
	public void testSupplierById() {
		
		assertEquals(1, supplierDao.findBySupplierId(1).getSupplierId());
	}
	@Test
	public void testFindAllSupplier() {
		
		assertEquals(1,supplierDao.findAllSupplier().size());
	}



}
