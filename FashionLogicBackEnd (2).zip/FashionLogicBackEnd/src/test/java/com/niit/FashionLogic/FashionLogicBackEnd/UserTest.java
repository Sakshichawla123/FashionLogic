package com.niit.FashionLogic.FashionLogicBackEnd;
import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.FashionLogic.DAO.UserDao;
import com.niit.FashionLogic.Model.User;

public class UserTest {
	@Autowired
	private static UserDao userDao;
	private static User user;
	private static AnnotationConfigApplicationContext context;
	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.*");
		context.refresh();
		userDao = (UserDao) context.getBean("userDao");
	}
	@Test
	public void addUsertest() {
		user=new User();
		user.setFirstname("Rahul");
		user.setLastname("Sharma");
		user.setEmail("r@gmail.com");
		user.setPassword("r@12");
		user.setRepassword("r@12");
		user.setPhone("546567564");
		user.setAddress("NIT 1 FBD");
		assertEquals("Successfully added the user",true, userDao.addUser(user));
	}
	
}
