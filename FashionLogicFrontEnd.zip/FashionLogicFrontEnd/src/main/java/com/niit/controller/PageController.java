package com.niit.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.niit.FashionLogic.DAO.CategoryDao;
import com.niit.FashionLogic.DAO.ProductDao;
import com.niit.FashionLogic.DAO.SupplierDao;
import com.niit.FashionLogic.DAO.UserDao;
import com.niit.FashionLogic.Model.Category;
import com.niit.FashionLogic.Model.Product;
import com.niit.FashionLogic.Model.Supplier;
import com.niit.FashionLogic.Model.User;

@Controller
public class PageController {
	@Autowired
	public CategoryDao categoryDao;
	@Autowired
	public UserDao userDao;
	@Autowired
	public ProductDao productDao;
	@Autowired
	public SupplierDao supplierDao;

@RequestMapping(value="/",method=RequestMethod.GET)
public ModelAndView viewCategory() {	
	ModelAndView mv = new ModelAndView("index");	
	List<Category> cat= categoryDao.findAllCategory();
	mv.addObject("category",cat);
	return mv;
}

@RequestMapping(value="/about",method=RequestMethod.GET)
public String aboutUs() {
	System.out.println("About Us Page");
	return "AboutUS";
}
@RequestMapping(value="/contact",method=RequestMethod.GET)
public String contactUs() {
	System.out.println("Contact Us Page");
	return "ContactUS";
}
@RequestMapping(value="/login",method=RequestMethod.GET)
public String login() {
	System.out.println("Login Page");
	return "Login";
}
@RequestMapping(value="/register",method=RequestMethod.GET)
public String register(Model model) {
	System.out.println("Register Page");
	User user = new User();
	model.addAttribute("userForm", user);
	return "Registration";
}
@RequestMapping(value="/submitSupplier",method=RequestMethod.POST)
public ModelAndView supplierProcess(HttpServletRequest request, HttpServletResponse response,
		  @ModelAttribute("supplierForm") Supplier supplier) {
	boolean check=supplierDao.addSupplier(supplier);
	System.out.println(check);
	if(check) {
		ModelAndView mv = new ModelAndView("AddProduct");
		List<Category> cat= categoryDao.findAllCategory();
		mv.addObject("category",cat);
		List<Supplier> sup= supplierDao.findAllSupplier();
		mv.addObject("supplier",sup);
		Product product = new Product();
		mv.addObject("productForm", product);
		mv.addObject("Success", "Supplier saved successfully");
		return mv;
}
	else {
		ModelAndView mv = new ModelAndView("AddSupplier");
return mv;
		
	}	
}

@RequestMapping(value="/submitUser",method=RequestMethod.POST)
public ModelAndView registerProcess(HttpServletRequest request, HttpServletResponse response,
		  @ModelAttribute("userForm") User user) {
	System.out.println("Registration successful Page");
	System.out.println(user.getFirstname());
	System.out.println(user.getLastname());
	System.out.println(user.getEmail());
	System.out.println(user.getAddress());
	System.out.println(user.getPassword());
	System.out.println(user.getRepassword());
	System.out.println(user.getPhone());
	boolean check=userDao.addUser(user);
	System.out.println(check);
	if(check) {
		ModelAndView mv = new ModelAndView("Login");
		mv.addObject("Success", "User saved successfully");
		return mv;
}
	else {
		ModelAndView mv = new ModelAndView("Registration");
return mv;
		
	}	
}
@RequestMapping(value="/submitCategory",method=RequestMethod.POST)
public ModelAndView CategoryProcess(HttpServletRequest request, HttpServletResponse response,
		  @ModelAttribute("categoryForm") Category category) {
	boolean check=categoryDao.addCategory(category);
	System.out.println(check);
	if(check) {
		ModelAndView mv = new ModelAndView("AddProduct");
		List<Category> cat= categoryDao.findAllCategory();
		mv.addObject("category",cat);
		List<Supplier> sup= supplierDao.findAllSupplier();
		mv.addObject("supplier",sup);
		Product product = new Product();
		mv.addObject("productForm", product);
		mv.addObject("Success", "Category saved successfully");
		return mv;
}
	else {
		ModelAndView mv = new ModelAndView("AddCategory");
return mv;
		
	}	
}
@RequestMapping(value="/submitProduct",method=RequestMethod.POST)
public ModelAndView productProcess(HttpServletRequest request, HttpServletResponse response,
		  @ModelAttribute("productForm") Product product) {
	
	boolean check=productDao.addProduct(product);
	System.out.println(check);
	if(check) {
		ModelAndView mv = new ModelAndView("view");
		List<Product> prod=productDao.findAll();
		mv.addObject("product",prod);
		mv.addObject("Success", "Product saved successfully");
		return mv;
}
	else {
		ModelAndView mv = new ModelAndView("AddProduct");
return mv;
		
	}	
}
}
