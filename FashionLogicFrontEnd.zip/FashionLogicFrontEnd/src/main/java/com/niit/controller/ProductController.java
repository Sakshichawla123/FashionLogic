package com.niit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.FashionLogic.DAO.CategoryDao;
import com.niit.FashionLogic.DAO.ProductDao;
import com.niit.FashionLogic.DAO.SupplierDao;
import com.niit.FashionLogic.Model.Category;
import com.niit.FashionLogic.Model.Product;
import com.niit.FashionLogic.Model.Supplier;
import com.niit.FashionLogic.Model.User;

@Controller
public class ProductController {
	@Autowired
	public CategoryDao categoryDao;
	@Autowired
	public SupplierDao supplierDao;
	@Autowired
	public ProductDao productDao;
	@RequestMapping(value="/product",method=RequestMethod.GET)
	public ModelAndView viewProduct() {	
		ModelAndView mv = new ModelAndView("view");	
		List<Product> prod=productDao.findAll();
		mv.addObject("product",prod);
		return mv;
	}
	@RequestMapping(value="/singleproduct/{prodId}",method=RequestMethod.GET)
	public ModelAndView singleProduct(@PathVariable(value="prodId") int prodId) {	
		ModelAndView mv = new ModelAndView("SingleProduct");
		Product p=productDao.findByProductId(prodId);
		mv.addObject("product",p);
		return mv;
	}
	@RequestMapping(value="/addproduct",method=RequestMethod.GET)
	public ModelAndView addProduct(Model model) {
		ModelAndView mv = new ModelAndView("AddProduct");
		System.out.println("Add Product Page");
		List<Category> cat= categoryDao.findAllCategory();
		mv.addObject("category",cat);
		List<Supplier> sup= supplierDao.findAllSupplier();
		mv.addObject("supplier",sup);
		Product product = new Product();
		model.addAttribute("productForm", product);
		return mv;
	}
	@RequestMapping(value="/addsupplier",method=RequestMethod.GET)
	public String addSupplier(Model model) {
		System.out.println("Add Supplier Page");
		Supplier supplier = new Supplier();
		model.addAttribute("supplierForm", supplier);
		return "AddSupplier";
}	
	@RequestMapping(value="/addcategory",method=RequestMethod.GET)
	public String addCategory(Model model) {
		System.out.println("Add Category Page");
		Category category = new Category();
		model.addAttribute("categoryForm", category);
		return "AddCategory";
}	
}